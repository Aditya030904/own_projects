import { useState } from "react";
import Header from "./components/Header";
import InputForm from "./components/InputForm";
import PipelineView from "./components/PipelineView";
import ResultsTabs from "./components/ResultsTabs";
import { runScriptwriter, runAssetAgent, runSEOAgent } from "./api/agents";
import "./App.css";

const STAGES = [
  { id: "script", label: "Agent 1", name: "Scriptwriter", color: "var(--agent1)", icon: "✍" },
  { id: "assets", label: "Agent 2", name: "Asset Gatherer", color: "var(--agent2)", icon: "🎨" },
  { id: "seo",    label: "Agent 3", name: "SEO Optimizer", color: "var(--agent3)", icon: "📈" },
];

export default function App() {
  const [topic, setTopic] = useState("");
  const [game, setGame] = useState("BGMI / PUBG Mobile");
  const [running, setRunning] = useState(false);
  const [activeStage, setActiveStage] = useState(null); // index 0-2
  const [stageStatus, setStageStatus] = useState({ script: "idle", assets: "idle", seo: "idle" });
  const [results, setResults] = useState({ script: null, assets: null, seo: null });
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  function setStage(id, status) {
    setStageStatus(prev => ({ ...prev, [id]: status }));
  }

  async function handleRun() {
    if (!topic.trim()) return;
    setRunning(true);
    setDone(false);
    setError("");
    setResults({ script: null, assets: null, seo: null });
    setStageStatus({ script: "idle", assets: "idle", seo: "idle" });

    try {
      // Agent 1
      setActiveStage(0);
      setStage("script", "running");
      const scriptData = await runScriptwriter(topic, game);
      setResults(prev => ({ ...prev, script: scriptData }));
      setStage("script", "done");

      // Agent 2
      setActiveStage(1);
      setStage("assets", "running");
      const assetData = await runAssetAgent(topic, scriptData, game);
      setResults(prev => ({ ...prev, assets: assetData }));
      setStage("assets", "done");

      // Agent 3
      setActiveStage(2);
      setStage("seo", "running");
      const seoData = await runSEOAgent(topic, scriptData, game);
      setResults(prev => ({ ...prev, seo: seoData }));
      setStage("seo", "done");

      setActiveStage(null);
      setDone(true);
    } catch (e) {
      setError(e.message);
      setActiveStage(null);
    } finally {
      setRunning(false);
    }
  }

  function handleReset() {
    setDone(false);
    setResults({ script: null, assets: null, seo: null });
    setStageStatus({ script: "idle", assets: "idle", seo: "idle" });
    setError("");
    setActiveStage(null);
  }

  return (
    <div className="app">
      <Header />
      <main className="main">
        {!done ? (
          <>
            <InputForm
              topic={topic}
              setTopic={setTopic}
              game={game}
              setGame={setGame}
              onRun={handleRun}
              running={running}
            />
            {(running || Object.values(stageStatus).some(s => s !== "idle")) && (
              <PipelineView stages={STAGES} stageStatus={stageStatus} activeStage={activeStage} />
            )}
            {error && (
              <div className="error-box">
                <span className="error-icon">⚠</span>
                <span>{error}</span>
              </div>
            )}
          </>
        ) : (
          <ResultsTabs
            results={results}
            stages={STAGES}
            topic={topic}
            game={game}
            onReset={handleReset}
          />
        )}
      </main>
    </div>
  );
}
