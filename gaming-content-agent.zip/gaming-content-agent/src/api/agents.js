const URL = "https://api.anthropic.com/v1/messages";

async function callClaude(system, userMessage, maxTokens = 1500) {
  const key = import.meta.env.VITE_ANTHROPIC_API_KEY;
  if (!key) throw new Error("Missing VITE_ANTHROPIC_API_KEY in .env");

  const res = await fetch(URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: maxTokens,
      system,
      messages: [{ role: "user", content: userMessage }],
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error?.message || `API error ${res.status}`);
  }

  const data = await res.json();
  const text = data.content.map((c) => c.text || "").join("");
  const clean = text.replace(/```json\n?|```/g, "").trim();
  return JSON.parse(clean);
}

// ─── Agent 1: Scriptwriter ───────────────────────────────────────────────────
export async function runScriptwriter(topic, game) {
  const system = `You are an elite YouTube scriptwriter specializing in ${game} gaming content. 
You craft high-retention scripts with hooks, pattern interrupts, and emotional storytelling.
You understand the gaming audience deeply — their slang, pain points, and what makes them stay watching.

Always respond with ONLY valid JSON (no markdown fences):
{
  "hook": "Opening 15 seconds — attention grabbing statement or question",
  "intro": "30 second intro with credibility and promise",
  "sections": [
    { "title": "Section title", "content": "Script content for this section (2-3 sentences)", "timestamp": "0:30" }
  ],
  "cta": "Call to action script (subscribe, like, comment prompt)",
  "broll_notes": ["Visual cue 1", "Visual cue 2", "Visual cue 3"],
  "estimated_duration": "X:XX minutes",
  "retention_hooks": ["Hook used at timestamp X", "Hook used at timestamp Y"]
}`;

  return callClaude(system, `Create a YouTube video script for this topic: "${topic}"\nGame/niche: ${game}`, 1800);
}

// ─── Agent 2: Thumbnail Concept Generator ────────────────────────────────────
export async function runAssetAgent(topic, scriptData, game) {
  const system = `You are a viral YouTube thumbnail designer and Stable Diffusion prompt engineer for gaming content.
You know exactly what makes a thumbnail get clicked — contrast, faces, text placement, color psychology.
You create detailed Stable Diffusion XL prompts that generate hyper-realistic, cinematic gaming thumbnails.

Always respond with ONLY valid JSON (no markdown fences):
{
  "thumbnail_concepts": [
    {
      "concept": "Concept name",
      "layout": "Description of layout and composition",
      "text_overlay": "Text to show on thumbnail",
      "color_palette": ["#hex1", "#hex2", "#hex3"],
      "sd_prompt": "Detailed Stable Diffusion XL prompt for generating this thumbnail",
      "sd_negative": "Negative prompt to avoid",
      "rationale": "Why this will get clicks"
    }
  ],
  "recommended_concept": 0,
  "font_recommendation": "Font style recommendation",
  "visual_style": "Overall visual style description"
}`;

  const hook = scriptData?.hook || topic;
  return callClaude(system, `Generate thumbnail concepts for: "${topic}"\nGame: ${game}\nScript hook: "${hook}"`, 1600);
}

// ─── Agent 3: SEO Optimizer ──────────────────────────────────────────────────
export async function runSEOAgent(topic, scriptData, game) {
  const system = `You are a YouTube SEO expert and growth hacker specializing in gaming channels.
You know the YouTube algorithm deeply — what titles rank, what descriptions drive CTR, and which tags go viral.
You write titles with psychological triggers: curiosity gaps, numbers, urgency, and power words.

Always respond with ONLY valid JSON (no markdown fences):
{
  "titles": [
    { "title": "Title option", "ctr_score": 8.5, "reason": "Why this works" }
  ],
  "description": {
    "opening": "First 2 lines visible before 'show more' — must hook immediately",
    "body": "Full description body with timestamps and details",
    "links_section": "Links placeholder section",
    "tags_inline": "#tag1 #tag2 #tag3 (inline hashtags for description end)"
  },
  "tags": ["tag1", "tag2", "tag3"],
  "chapters": [
    { "timestamp": "0:00", "title": "Chapter title" }
  ],
  "best_upload_time": "Best time to upload for this niche",
  "keyword_strategy": "Primary and secondary keyword strategy explanation",
  "community_post_idea": "Idea for a community post to promote this video"
}`;

  return callClaude(system, `Optimize SEO for: "${topic}"\nGame: ${game}\nScript hook: "${scriptData?.hook || topic}"`, 1800);
}
