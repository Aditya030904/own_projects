import "./PipelineView.css";

const AGENT_MESSAGES = {
  script: [
    "Analyzing topic and target audience...",
    "Crafting high-retention hook...",
    "Building script structure with timestamps...",
    "Adding pattern interrupts and CTAs...",
  ],
  assets: [
    "Extracting key visual themes from script...",
    "Designing thumbnail composition concepts...",
    "Generating Stable Diffusion XL prompts...",
    "Optimizing for CTR and visual impact...",
  ],
  seo: [
    "Researching trending keywords...",
    "Crafting click-bait optimized titles...",
    "Building SEO description with chapters...",
    "Analyzing best upload timing...",
  ],
};

export default function PipelineView({ stages, stageStatus, activeStage }) {
  return (
    <div className="pipeline-view animate-in">
      <div className="pipeline-header">
        <span className="pipeline-label">// PIPELINE EXECUTION</span>
        <span className="pipeline-live">
          <span className="live-dot" />
          LIVE
        </span>
      </div>

      <div className="pipeline-stages">
        {stages.map((stage, i) => {
          const status = stageStatus[stage.id];
          const isActive = activeStage === i;

          return (
            <div key={stage.id} className={`stage-card ${status}`} style={{ "--stage-color": stage.color }}>
              <div className="stage-top">
                <div className="stage-icon-wrap">
                  <span className="stage-icon">{stage.icon}</span>
                  {status === "running" && <span className="stage-ring" />}
                </div>
                <div className="stage-info">
                  <div className="stage-label">{stage.label}</div>
                  <div className="stage-name">{stage.name}</div>
                </div>
                <div className="stage-status-badge">
                  {status === "idle" && <span className="s-idle">QUEUED</span>}
                  {status === "running" && <span className="s-running">ACTIVE</span>}
                  {status === "done" && <span className="s-done">✓ DONE</span>}
                </div>
              </div>

              {isActive && (
                <div className="stage-progress-bar">
                  <div className="progress-fill" />
                </div>
              )}

              {isActive && (
                <div className="stage-log">
                  {AGENT_MESSAGES[stage.id].map((msg, mi) => (
                    <div
                      key={mi}
                      className="log-line"
                      style={{ animationDelay: `${mi * 0.6}s` }}
                    >
                      <span className="log-arrow">&gt;</span> {msg}
                    </div>
                  ))}
                </div>
              )}

              {status === "done" && (
                <div className="stage-done-msg">Output generated successfully</div>
              )}

              {i < stages.length - 1 && (
                <div className="stage-connector">
                  <div className={`connector-line ${status === "done" ? "active" : ""}`} />
                  <span className="connector-arrow">↓</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
