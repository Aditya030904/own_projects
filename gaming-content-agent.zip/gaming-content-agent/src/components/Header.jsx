import "./Header.css";

export default function Header() {
  return (
    <header className="header">
      <div className="header-inner">
        <div className="header-logo">
          <div className="logo-mark">
            <span className="logo-hex">⬡</span>
            <span className="logo-text">NEXUS<span className="logo-accent">AI</span></span>
          </div>
          <div className="logo-sub">Gaming Content Pipeline</div>
        </div>
        <div className="header-badges">
          <span className="badge badge-agent1">Agent 1: Script</span>
          <span className="badge-arrow">→</span>
          <span className="badge badge-agent2">Agent 2: Assets</span>
          <span className="badge-arrow">→</span>
          <span className="badge badge-agent3">Agent 3: SEO</span>
        </div>
      </div>
      <div className="header-scan-line" />
    </header>
  );
}
