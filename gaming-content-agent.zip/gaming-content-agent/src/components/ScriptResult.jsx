import "./Results.css";

function CopyBtn({ text }) {
  function copy() { navigator.clipboard.writeText(text).catch(() => {}); }
  return <button className="inline-copy" onClick={copy}>copy</button>;
}

export default function ScriptResult({ data }) {
  if (!data) return <div className="no-data">No script data available.</div>;

  return (
    <div className="script-result">
      <div className="result-meta-row">
        <span className="meta-pill">⏱ {data.estimated_duration}</span>
        {data.retention_hooks?.map((h, i) => (
          <span key={i} className="meta-pill meta-hook">🎣 {h}</span>
        ))}
      </div>

      <div className="script-block hook-block">
        <div className="block-label agent1-label">// HOOK (0:00 – 0:15)</div>
        <div className="block-content hook-text">{data.hook}</div>
        <CopyBtn text={data.hook} />
      </div>

      <div className="script-block">
        <div className="block-label agent1-label">// INTRO</div>
        <div className="block-content">{data.intro}</div>
        <CopyBtn text={data.intro} />
      </div>

      {data.sections?.map((section, i) => (
        <div key={i} className="script-block section-block">
          <div className="section-header">
            <span className="timestamp-badge">{section.timestamp}</span>
            <span className="section-title">{section.title}</span>
          </div>
          <div className="block-content">{section.content}</div>
          <CopyBtn text={section.content} />
        </div>
      ))}

      <div className="script-block cta-block">
        <div className="block-label agent1-label">// CALL TO ACTION</div>
        <div className="block-content">{data.cta}</div>
        <CopyBtn text={data.cta} />
      </div>

      {data.broll_notes?.length > 0 && (
        <div className="script-block">
          <div className="block-label">// B-ROLL NOTES</div>
          <ul className="broll-list">
            {data.broll_notes.map((note, i) => (
              <li key={i} className="broll-item">
                <span className="broll-arrow">▸</span> {note}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
