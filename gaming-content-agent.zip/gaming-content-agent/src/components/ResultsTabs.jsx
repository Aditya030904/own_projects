import { useState } from "react";
import ScriptResult from "./ScriptResult";
import AssetResult from "./AssetResult";
import SEOResult from "./SEOResult";
import "./ResultsTabs.css";

export default function ResultsTabs({ results, stages, topic, game, onReset }) {
  const [activeTab, setActiveTab] = useState(0);

  function copyAll() {
    const text = [
      `=== GAMING CONTENT PACKAGE ===`,
      `Topic: ${topic} | Game: ${game}`,
      ``,
      `--- SCRIPT ---`,
      results.script ? `Hook: ${results.script.hook}\n\nSections:\n${results.script.sections?.map(s => `${s.timestamp} ${s.title}: ${s.content}`).join('\n')}` : '',
      ``,
      `--- SEO TITLES ---`,
      results.seo?.titles?.map(t => t.title).join('\n') || '',
      ``,
      `--- TAGS ---`,
      results.seo?.tags?.join(', ') || '',
      ``,
      `--- THUMBNAIL SD PROMPT ---`,
      results.assets?.thumbnail_concepts?.[results.assets.recommended_concept]?.sd_prompt || '',
    ].join('\n');
    navigator.clipboard.writeText(text).catch(() => {});
  }

  return (
    <div className="results-container animate-in">
      <div className="results-header">
        <div>
          <div className="results-complete">✓ PIPELINE COMPLETE</div>
          <div className="results-topic">"{topic}"</div>
        </div>
        <div className="results-actions">
          <button className="action-btn copy-btn" onClick={copyAll}>⊕ Copy All</button>
          <button className="action-btn reset-btn" onClick={onReset}>↺ New Topic</button>
        </div>
      </div>

      <div className="result-tabs">
        {stages.map((stage, i) => (
          <button
            key={stage.id}
            className={`result-tab ${activeTab === i ? "active" : ""}`}
            style={{ "--tab-color": stage.color }}
            onClick={() => setActiveTab(i)}
          >
            <span className="tab-icon">{stage.icon}</span>
            <span className="tab-label">{stage.name}</span>
          </button>
        ))}
      </div>

      <div className="result-panel">
        {activeTab === 0 && <ScriptResult data={results.script} />}
        {activeTab === 1 && <AssetResult data={results.assets} />}
        {activeTab === 2 && <SEOResult data={results.seo} />}
      </div>
    </div>
  );
}
