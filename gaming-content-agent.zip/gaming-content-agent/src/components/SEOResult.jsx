import "./Results.css";

function CopyBtn({ text }) {
  function copy() { navigator.clipboard.writeText(text).catch(() => {}); }
  return <button className="inline-copy" onClick={copy}>copy</button>;
}

function CTRBar({ score }) {
  const pct = (score / 10) * 100;
  const color = score >= 8 ? "var(--accent)" : score >= 6 ? "var(--agent3)" : "var(--accent2)";
  return (
    <div className="ctr-bar-wrap">
      <div className="ctr-bar">
        <div className="ctr-fill" style={{ width: `${pct}%`, background: color }} />
      </div>
      <span className="ctr-score" style={{ color }}>{score}/10</span>
    </div>
  );
}

export default function SEOResult({ data }) {
  if (!data) return <div className="no-data">No SEO data available.</div>;

  const fullDesc = [
    data.description?.opening,
    "",
    data.description?.body,
    "",
    data.description?.links_section,
    "",
    data.description?.tags_inline,
  ].join("\n");

  const allTags = data.tags?.join(", ") || "";

  return (
    <div className="seo-result">

      <div className="seo-section">
        <div className="block-label agent3-label">// TITLE OPTIONS (CTR SCORED)</div>
        <div className="titles-list">
          {data.titles?.map((t, i) => (
            <div key={i} className="title-row">
              <div className="title-rank">#{i + 1}</div>
              <div className="title-content">
                <div className="title-text">{t.title}</div>
                <div className="title-reason">{t.reason}</div>
                <CTRBar score={t.ctr_score} />
              </div>
              <CopyBtn text={t.title} />
            </div>
          ))}
        </div>
      </div>

      <div className="seo-section">
        <div className="block-label agent3-label">// FULL DESCRIPTION</div>
        <div className="desc-box">
          <div className="desc-opening">{data.description?.opening}</div>
          <div className="desc-divider" />
          <div className="desc-body">{data.description?.body}</div>
          {data.description?.links_section && (
            <>
              <div className="desc-divider" />
              <div className="desc-links">{data.description?.links_section}</div>
            </>
          )}
          <div className="desc-divider" />
          <div className="desc-tags-inline">{data.description?.tags_inline}</div>
        </div>
        <CopyBtn text={fullDesc} />
      </div>

      <div className="seo-grid">
        <div className="seo-section">
          <div className="block-label agent3-label">// VIDEO CHAPTERS</div>
          <div className="chapters-list">
            {data.chapters?.map((ch, i) => (
              <div key={i} className="chapter-row">
                <span className="chapter-ts">{ch.timestamp}</span>
                <span className="chapter-title">{ch.title}</span>
              </div>
            ))}
          </div>
          <CopyBtn text={data.chapters?.map(c => `${c.timestamp} ${c.title}`).join('\n')} />
        </div>

        <div className="seo-section">
          <div className="block-label agent3-label">// TAGS ({data.tags?.length})</div>
          <div className="tags-cloud">
            {data.tags?.map((tag, i) => (
              <span key={i} className="tag-pill">{tag}</span>
            ))}
          </div>
          <CopyBtn text={allTags} />
        </div>
      </div>

      <div className="seo-insights">
        <div className="insight-card">
          <div className="insight-icon">🕐</div>
          <div className="insight-label">Best Upload Time</div>
          <div className="insight-val">{data.best_upload_time}</div>
        </div>
        <div className="insight-card">
          <div className="insight-icon">🔑</div>
          <div className="insight-label">Keyword Strategy</div>
          <div className="insight-val">{data.keyword_strategy}</div>
        </div>
        <div className="insight-card">
          <div className="insight-icon">📣</div>
          <div className="insight-label">Community Post Idea</div>
          <div className="insight-val">{data.community_post_idea}</div>
        </div>
      </div>
    </div>
  );
}
