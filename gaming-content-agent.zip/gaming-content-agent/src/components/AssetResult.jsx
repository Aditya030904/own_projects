import "./Results.css";

function CopyBtn({ text }) {
  function copy() { navigator.clipboard.writeText(text).catch(() => {}); }
  return <button className="inline-copy" onClick={copy}>copy</button>;
}

function ColorSwatch({ color }) {
  return (
    <span
      className="color-swatch"
      style={{ background: color }}
      title={color}
    />
  );
}

export default function AssetResult({ data }) {
  if (!data) return <div className="no-data">No asset data available.</div>;

  const recommended = data.recommended_concept ?? 0;

  return (
    <div className="asset-result">
      <div className="asset-meta">
        <div className="meta-row">
          <span className="meta-label">Visual Style:</span>
          <span className="meta-value">{data.visual_style}</span>
        </div>
        <div className="meta-row">
          <span className="meta-label">Font Rec:</span>
          <span className="meta-value">{data.font_recommendation}</span>
        </div>
      </div>

      <div className="concepts-grid">
        {data.thumbnail_concepts?.map((concept, i) => (
          <div key={i} className={`concept-card ${i === recommended ? "recommended" : ""}`}>
            {i === recommended && (
              <div className="recommended-badge">⭐ RECOMMENDED</div>
            )}
            <div className="concept-name">{concept.concept}</div>

            <div className="concept-section">
              <div className="block-label agent2-label">// LAYOUT</div>
              <div className="concept-text">{concept.layout}</div>
            </div>

            <div className="concept-section">
              <div className="block-label agent2-label">// TEXT OVERLAY</div>
              <div className="overlay-preview">{concept.text_overlay}</div>
            </div>

            <div className="concept-section">
              <div className="block-label agent2-label">// COLOR PALETTE</div>
              <div className="palette-row">
                {concept.color_palette?.map((c, ci) => (
                  <ColorSwatch key={ci} color={c} />
                ))}
              </div>
            </div>

            <div className="concept-section">
              <div className="block-label agent2-label">// STABLE DIFFUSION XL PROMPT</div>
              <div className="sd-prompt-box">
                <div className="sd-prompt-text">{concept.sd_prompt}</div>
                <CopyBtn text={concept.sd_prompt} />
              </div>
            </div>

            <div className="concept-section">
              <div className="block-label" style={{ color: "var(--accent2)" }}>// NEGATIVE PROMPT</div>
              <div className="negative-prompt">{concept.sd_negative}</div>
              <CopyBtn text={concept.sd_negative} />
            </div>

            <div className="concept-section">
              <div className="block-label">// WHY IT WORKS</div>
              <div className="rationale">{concept.rationale}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
