import "./InputForm.css";

const GAMES = [
  "BGMI / PUBG Mobile",
  "PUBG PC",
  "Free Fire",
  "Valorant",
  "Call of Duty: Warzone",
  "Apex Legends",
  "CS2 / CSGO",
  "Fortnite",
  "Minecraft",
  "General Esports",
];

const EXAMPLE_TOPICS = [
  "Top 5 sensitivity settings for pro players",
  "How to drop hot and survive every time",
  "Best loadout for ranked matches 2025",
  "How to improve your aim in 7 days",
  "Hidden spots that pro players use",
];

export default function InputForm({ topic, setTopic, game, setGame, onRun, running }) {
  return (
    <div className="input-form">
      <div className="form-header">
        <h2 className="form-title">INITIALIZE PIPELINE</h2>
        <p className="form-sub">Input your content topic — the three-agent system handles everything else.</p>
      </div>

      <div className="form-fields">
        <div className="field-group">
          <label className="field-label">
            <span className="label-prefix">//</span> CONTENT TOPIC
          </label>
          <textarea
            className="topic-input"
            value={topic}
            onChange={e => setTopic(e.target.value)}
            placeholder="e.g. Top 5 sensitivity settings for pro players..."
            rows={3}
          />
          <div className="example-chips">
            {EXAMPLE_TOPICS.slice(0, 3).map(ex => (
              <button key={ex} className="chip" onClick={() => setTopic(ex)}>
                {ex}
              </button>
            ))}
          </div>
        </div>

        <div className="field-row">
          <div className="field-group field-half">
            <label className="field-label">
              <span className="label-prefix">//</span> GAME / NICHE
            </label>
            <select className="game-select" value={game} onChange={e => setGame(e.target.value)}>
              {GAMES.map(g => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>

          <div className="field-group field-half">
            <label className="field-label">
              <span className="label-prefix">//</span> PIPELINE STATUS
            </label>
            <div className="status-display">
              <span className={`status-dot ${running ? "running" : "ready"}`} />
              <span className="status-text">{running ? "AGENTS ACTIVE" : "READY TO DEPLOY"}</span>
            </div>
          </div>
        </div>

        <button
          className={`run-btn ${running ? "running" : ""}`}
          onClick={onRun}
          disabled={running || !topic.trim()}
        >
          {running ? (
            <>
              <span className="btn-spinner" />
              PIPELINE RUNNING...
            </>
          ) : (
            <>
              <span className="btn-icon">▶</span>
              LAUNCH AGENT PIPELINE
            </>
          )}
        </button>
      </div>
    </div>
  );
}
