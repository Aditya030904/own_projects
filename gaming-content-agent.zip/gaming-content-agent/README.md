# 🎮 Autonomous Gaming Content Creator Agent

A multi-agent AI pipeline that turns a single topic into a **complete YouTube content package** — script, thumbnail concepts, and SEO — in under 60 seconds.

![React](https://img.shields.io/badge/React-18-61DAFB?logo=react) ![Vite](https://img.shields.io/badge/Vite-5-646CFF?logo=vite) ![Claude](https://img.shields.io/badge/Claude-Sonnet-CC785C) ![License](https://img.shields.io/badge/License-MIT-green)

---

## 🤖 The Three-Agent Pipeline

```
[Your Topic] → Agent 1 → Agent 2 → Agent 3 → [Full Content Package]
```

| Agent | Role | Output |
|-------|------|--------|
| **Agent 1 — Scriptwriter** | Generates high-retention video scripts | Hook, intro, timestamped sections, CTA, B-roll notes |
| **Agent 2 — Asset Gatherer** | Creates thumbnail concepts + image AI prompts | 2 thumbnail concepts with Stable Diffusion XL prompts, color palettes, layout guides |
| **Agent 3 — SEO Optimizer** | Maximizes discoverability | 3 CTR-scored titles, full description, 20+ tags, video chapters, upload timing |

---

## ✨ Features

- 🎯 **Topic-to-package in ~45 seconds** — just type a topic and click launch
- 🧠 **Sequential agent orchestration** — each agent builds on the previous agent's output
- 🎨 **Stable Diffusion XL prompts** — ready to paste into SDXL, ComfyUI, or Midjourney
- 📊 **CTR scoring** — titles scored 1–10 with reasoning
- 📋 **One-click copy** for every output section
- 🎮 **Supports BGMI, PUBG, Valorant, CS2, Apex, Fortnite** and more
- 🌙 **Dark gaming aesthetic** — Orbitron + Rajdhani fonts, neon accents, scan-line effects

---

## 🚀 Quick Start

### 1. Clone

```bash
git clone https://github.com/YOUR_USERNAME/gaming-content-agent.git
cd gaming-content-agent
```

### 2. Install

```bash
npm install
```

### 3. Configure API key

```bash
cp .env.example .env
# Edit .env and add your Anthropic API key
```

Get a key at [console.anthropic.com](https://console.anthropic.com).

### 4. Run

```bash
npm run dev
# Open http://localhost:5173
```

---

## 📁 Project Structure

```
gaming-content-agent/
├── src/
│   ├── api/
│   │   └── agents.js              # Three agent API calls with system prompts
│   ├── components/
│   │   ├── Header.jsx / .css      # Logo + agent pipeline badges
│   │   ├── InputForm.jsx / .css   # Topic input, game selector, example chips
│   │   ├── PipelineView.jsx / .css # Live agent execution display
│   │   ├── ResultsTabs.jsx / .css # Tab navigation for results
│   │   ├── ScriptResult.jsx       # Script display with timestamps
│   │   ├── AssetResult.jsx        # Thumbnail concepts + SD prompts
│   │   ├── SEOResult.jsx          # Titles, description, tags, chapters
│   │   └── Results.css            # Shared result styles
│   ├── App.jsx / .css             # Pipeline orchestration
│   ├── main.jsx                   # React entry
│   └── index.css                  # Global dark theme
├── index.html
├── vite.config.js
├── package.json
├── .env.example
└── .gitignore
```

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + Vite |
| AI Model | Claude Sonnet (`claude-sonnet-4-20250514`) |
| Styling | Pure CSS, CSS variables, Orbitron + Rajdhani fonts |
| Image Generation | Stable Diffusion XL (via SD prompts) |

### Extending with Real Image Generation

To add actual thumbnail generation, swap the SD prompt output with any of these APIs:

- **Stable Diffusion XL** — [Stability AI API](https://platform.stability.ai)
- **Replicate** — `replicate.run("stability-ai/sdxl", { prompt })`
- **Midjourney** — via unofficial API wrappers
- **DALL-E 3** — `openai.images.generate({ prompt, model: "dall-e-3" })`

---

## 🎯 Example Output

**Input:** `"Top 5 sensitivity settings for pro players"` + `BGMI / PUBG Mobile`

**Agent 1 Output:**
- Hook: "99% of BGMI players are using the WRONG sensitivity..."
- 5 timestamped sections with B-roll cues
- Estimated duration: 8:30 minutes

**Agent 2 Output:**
- 2 thumbnail concepts with SD XL prompts
- Color palettes + text overlays
- Ready-to-generate prompts for Stable Diffusion

**Agent 3 Output:**
- 3 titles (CTR scored 8.2–9.1/10)
- Full SEO description with chapters
- 25 optimized tags
- Upload timing recommendation

---

## 🔐 Security Note

API key is used client-side via `VITE_` prefix. For production, move API calls to a backend (Node/Express, FastAPI) and never expose the key publicly.

---

## 📄 License

MIT — use freely, credit appreciated.
