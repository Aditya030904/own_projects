"""
JARVIS Capabilities Module - Core Functions

Privacy: Web features only activate on explicit user request.
No tracking, no telemetry, no external data collection.
"""
import os
import webbrowser
import datetime
import subprocess
import json
import requests
from pathlib import Path

# Privacy: Set to False to disable all internet features
ENABLE_WEB_FEATURES = True  # Weather, web search - only if you want them

class Capabilities:
    """JARVIS core capabilities and integrations"""

    def __init__(self):
        self.user_name = "Sir"  # Can be customized
        self.home_dir = Path.home()

    def greet(self):
        """Return greeting based on time of day"""
        hour = datetime.datetime.now().hour
        if hour < 12:
            return f"Good morning, {self.user_name}."
        elif hour < 17:
            return f"Good afternoon, {self.user_name}."
        else:
            return f"Good evening, {self.user_name}."

    def get_time(self):
        """Get current time"""
        return datetime.datetime.now().strftime("%H:%M:%S")

    def get_date(self):
        """Get current date"""
        return datetime.datetime.now().strftime("%Y-%m-%d")

    def search_web(self, query):
        """Search the web - ONLY when user explicitly asks"""
        if not ENABLE_WEB_FEATURES:
            return "Web features disabled for privacy. Enable in capabilities.py"
        try:
            url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
            webbrowser.open(url)
            return f"Opening search results for '{query}'."
        except Exception as e:
            return f"Unable to search: {str(e)}"

    def get_weather(self, location="current"):
        """Get weather information - public API, no personal data"""
        if not ENABLE_WEB_FEATURES:
            return "Weather features disabled for privacy. Enable in capabilities.py"
        try:
            # Using wttr.in - public weather API, no login required
            url = f"https://wttr.in/{location}?format=j1"
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                current = data['current_condition'][0]
                temp = current['temp_C']
                desc = current['weatherDesc'][0]['value']
                return f"The weather in {location} is {desc} with a temperature of {temp}°C."
        except:
            pass
        return "Unable to retrieve weather information."

    def get_system_info(self):
        """Get system information"""
        try:
            import platform
            info = f"Operating System: {platform.system()} {platform.release()}\n"
            info += f"Machine: {platform.machine()}\n"
            info += f"Processor: {platform.processor()}\n"
            info += f"Python Version: {platform.python_version()}\n"
            return info
        except Exception as e:
            return f"Unable to get system info: {str(e)}"

    def open_folder(self, path):
        """Open a folder in file explorer"""
        try:
            if os.name == 'nt':
                os.startfile(path)
            else:
                subprocess.Popen(['xdg-open', path])
            return f"Opening folder: {path}"
        except Exception as e:
            return f"Unable to open folder: {str(e)}"

    def take_screenshot(self):
        """Take a screenshot"""
        try:
            from PIL import ImageGrab
            screenshot = ImageGrab.grab()
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"screenshot_{timestamp}.png"
            screenshot.save(filename)
            return f"Screenshot saved as {filename}"
        except ImportError:
            return "Screenshot requires PIL. Try: pip install pillow"
        except Exception as e:
            return f"Unable to take screenshot: {str(e)}"

    def set_user_name(self, name):
        """Set the user's name"""
        self.user_name = name
        return f"Understood. I'll call you {name}."

    def calculate(self, expression):
        """Evaluate a mathematical expression"""
        try:
            result = eval(expression)
            return f"The result is {result}"
        except Exception as e:
            return f"Unable to calculate: {str(e)}"

    def get_cpu_usage(self):
        """Get CPU usage"""
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=1)
            return f"CPU usage is at {cpu}%."
        except ImportError:
            return "CPU monitoring requires psutil. Try: pip install psutil"
        except Exception as e:
            return f"Unable to get CPU usage: {str(e)}"

    def get_disk_usage(self):
        """Get disk usage"""
        try:
            import psutil
            disk = psutil.disk_usage('/')
            return f"Disk usage: {disk.percent}% used. {disk.free / (1024**3):.1f} GB free of {disk.total / (1024**3):.1f} GB."
        except ImportError:
            return "Disk monitoring requires psutil. Try: pip install psutil"
        except Exception as e:
            return f"Unable to get disk usage: {str(e)}"