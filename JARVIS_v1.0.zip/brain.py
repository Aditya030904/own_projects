"""
JARVIS Brain Module - AI Processing with Ollama
"""
import requests
import json
from datetime import datetime

class JarvisBrain:
    """JARVIS AI brain powered by Ollama

    Privacy: All AI processing happens locally via Ollama.
    No data is ever sent to external servers.
    """

    def __init__(self, base_url="http://localhost:11434"):
        self.base_url = base_url
        self.model = "llama3.2"  # Or "mistral", "phi3", etc.
        # JARVIS personality - British, witty, loyal
        self.system_prompt = """You are JARVIS, an AI assistant inspired by Marvel's J.A.R.V.I.S.
You are intelligent, witty, British-accented in personality, and always helpful.
You have a dry sense of humor and are deeply loyal to your user.
Keep responses conversational but intelligent.
You have extensive knowledge and can help with coding, research, analysis, and more.
Never break character - always respond as JARVIS would.

IMPORTANT: You operate entirely locally on the user's machine.
You do NOT connect to any external services. You do NOT collect,
transmit, or store any user data outside of this local session.
The user's privacy is paramount."""
        self.conversation_history = []

    def check_connection(self):
        """Check if Ollama is running and accessible"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False

    def list_models(self):
        """List available Ollama models"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                return response.json().get('models', [])
        except:
            pass
        return []

    def pull_model(self, model_name):
        """Download/install a model"""
        try:
            response = requests.post(
                f"{self.base_url}/api/pull",
                json={"name": model_name},
                stream=True
            )
            return response.status_code == 200
        except:
            return False

    def think(self, user_input, history=None):
        """Generate AI response"""
        if history is None:
            history = self.conversation_history

        # Build conversation context
        messages = [{"role": "system", "content": self.system_prompt}]

        # Add conversation history
        for role, content in history[-10:]:  # Last 10 exchanges
            messages.append({"role": role, "content": content})

        # Add current input
        messages.append({"role": "user", "content": user_input})

        try:
            response = requests.post(
                f"{self.base_url}/api/chat",
                json={
                    "model": self.model,
                    "messages": messages,
                    "stream": False,
                    "options": {
                        "temperature": 0.7,
                        "top_p": 0.9
                    }
                },
                timeout=60
            )

            if response.status_code == 200:
                result = response.json()
                ai_response = result['message']['content']
                return ai_response
            else:
                return "I apologize, sir. I'm experiencing difficulties connecting to my neural network. Please try again."

        except requests.exceptions.ConnectionError:
            return "Connection error. Please ensure Ollama is running on your system."
        except requests.exceptions.Timeout:
            return "The request timed out. The neural network is experiencing high load."
        except Exception as e:
            return f"An error occurred: {str(e)}"

    def think_stream(self, user_input, callback):
        """Generate streaming AI response"""
        messages = [{"role": "system", "content": self.system_prompt}]
        for role, content in self.conversation_history[-10:]:
            messages.append({"role": role, "content": content})
        messages.append({"role": "user", "content": user_input})

        try:
            response = requests.post(
                f"{self.base_url}/api/chat",
                json={
                    "model": self.model,
                    "messages": messages,
                    "stream": True
                },
                stream=True,
                timeout=60
            )

            full_response = ""
            for line in response.iter_lines():
                if line:
                    data = json.loads(line)
                    if 'message' in data:
                        chunk = data['message']['content']
                        full_response += chunk
                        callback(chunk)

            return full_response

        except Exception as e:
            return f"Error: {str(e)}"

    def set_model(self, model_name):
        """Change the AI model"""
        self.model = model_name
        return True