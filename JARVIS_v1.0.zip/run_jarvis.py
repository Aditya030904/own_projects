"""
JARVIS Auto-Restarter - Opens main.py without console window
"""
import subprocess
import sys
import os
from pathlib import Path

# Change to JARVIS directory
jarvis_dir = Path(__file__).parent
os.chdir(jarvis_dir)

# Run main.py without console
main_script = jarvis_dir / "main.py"

# Use pythonw.exe to hide console window completely
pythonw = sys.executable.replace('python.exe', 'pythonw.exe')

# Run without showing any window
subprocess.Popen([pythonw, str(main_script)],
                 creationflags=0x08000000 if os.name == 'nt' else 0,
                 cwd=str(jarvis_dir))