"""
JARVIS Voice Module - Speech Recognition & Synthesis
Uses text-to-speech via pyttsx3.
Speech-to-text via Google API (requires internet) or skip if PyAudio unavailable.
"""
import sys

# Try to import optional voice dependencies
TTS_AVAILABLE = False
STT_AVAILABLE = False

try:
    import pyttsx3
    TTS_AVAILABLE = True
except ImportError:
    print("pyttsx3 not available - TTS disabled")

try:
    import speech_recognition as sr
    # Check if pyaudio is available
    try:
        _ = sr.Microphone()
        STT_AVAILABLE = True
    except:
        print("PyAudio/microphone not available - voice input disabled")
        STT_AVAILABLE = False
except ImportError:
    print("speech_recognition not available - voice input disabled")

import threading
import queue
import time

# Privacy setting: Set to True for full offline operation
USE_OFFLINE_STT = False

class VoiceManager:
    """Handles speech recognition and synthesis"""

    def __init__(self):
        self.recognizer = None
        self.microphone = None
        self.tts_engine = None
        self.is_listening = False
        self.audio_queue = queue.Queue()
        self.voice_available = STT_AVAILABLE
        self.tts_available = TTS_AVAILABLE

        self._init_voice()

    def _init_voice(self):
        """Initialize voice components with error handling"""
        # Initialize TTS
        if TTS_AVAILABLE:
            try:
                self.tts_engine = pyttsx3.init()
                self.tts_engine.setProperty('rate', 150)
                self.tts_engine.setProperty('volume', 0.9)

                # Try to set a British-ish voice
                try:
                    voices = self.tts_engine.getProperty('voices')
                    for voice in voices:
                        if 'english' in voice.name.lower() or 'uk' in voice.name.lower():
                            self.tts_engine.setProperty('voice', voice.id)
                            break
                except:
                    pass
                print("TTS engine ready.")
            except Exception as e:
                print(f"TTS init warning: {e}")
                self.tts_available = False

        # Initialize microphone
        if STT_AVAILABLE:
            try:
                self.recognizer = sr.Recognizer()
                self.microphone = sr.Microphone()
                # Test if microphone works
                with self.microphone as source:
                    self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                print("Voice input ready.")
            except Exception as e:
                print(f"Microphone warning: {e}")
                print("Voice input disabled - using text only mode")
                self.voice_available = False

    def init(self):
        """Initialize voice components"""
        if self.voice_available:
            print("Voice system ready.")
        else:
            print("Voice input not available - text mode only.")

    def listen(self, callback):
        """Listen for voice input in background"""
        if not self.voice_available or not self.recognizer:
            return

        self.is_listening = True

        def audio_callback(recognizer, audio):
            """Callback for audio data"""
            try:
                if USE_OFFLINE_STT:
                    # For offline, fall back to Google
                    text = recognizer.recognize_google(audio)
                else:
                    text = recognizer.recognize_google(audio)
                if text:
                    self.audio_queue.put(text)
            except Exception:
                pass  # Could not understand or service unavailable

        # Start listening in background
        try:
            stop_listening = self.recognizer.listen_in_background(
                self.microphone,
                audio_callback,
                phrase_time_limit=10
            )

            # Process queue
            def process_queue():
                while self.is_listening:
                    try:
                        text = self.audio_queue.get(timeout=0.5)
                        if text:
                            callback(text)
                    except queue.Empty:
                        pass

            threading.Thread(target=process_queue, daemon=True).start()
        except Exception as e:
            print(f"Voice listen error: {e}")
            self.voice_available = False

    def stop_listening(self):
        """Stop listening for voice input"""
        self.is_listening = False

    def speak(self, text):
        """Convert text to speech"""
        if not self.tts_available or not self.tts_engine:
            return

        def speak_worker():
            try:
                self.tts_engine.say(text)
                self.tts_engine.runAndWait()
            except Exception as e:
                print(f"TTS error: {e}")

        thread = threading.Thread(target=speak_worker, daemon=True)
        thread.start()
        thread.join(timeout=30)

    def speak_async(self, text):
        """Speak text asynchronously"""
        if not self.tts_available or not self.tts_engine:
            return

        def speak_worker():
            try:
                self.tts_engine.say(text)
                self.tts_engine.runAndWait()
            except:
                pass

        thread = threading.Thread(target=speak_worker, daemon=True)
        thread.start()

    def test_voice(self):
        """Test voice output"""
        if self.tts_available:
            self.speak("Hello, sir. Voice systems operational.")
        else:
            print("TTS not available.")

    def list_voices(self):
        """List available TTS voices"""
        if not self.tts_available:
            print("No TTS available")
            return
        voices = self.tts_engine.getProperty('voices')
        for i, voice in enumerate(voices):
            print(f"{i}: {voice.name} - {voice.languages}")