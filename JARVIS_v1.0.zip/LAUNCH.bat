@echo off
title JARVIS - Just A Rather Very Intelligent System
color 0A
echo.
echo  ██╗    ██╗██████╗  ██████╗ ███████╗██████╗ ██╗     ██╗███████╗██╗ ██████╗ ███╗   ██╗
echo  ██║    ██║██╔══██╗██╔════╝ ██╔════╝██╔══██╗██║     ██║╚══███╔╝██║██╔═══██╗████╗  ██║
echo  ██║ █╗ ██║██████╔╝██║  ███╗█████╗  ██████╔╝██║     ██║  ███╔╝ ██║██║   ██║██╔██╗ ██║
echo  ██║███╗██║██╔══██╗██║   ██║██╔══╝  ██╔══██╗██║     ██║ ███╔╝  ██║██║   ██║██║╚██╗██║
echo  ╚███╔███╔╝██████╔╝╚██████╔╝███████╗██████╔╝███████╗██║███████╗██║╚██████╔╝██║ ╚████║
echo   ╚══╝╚══╝ ╚═════╝  ╚═════╝ ╚══════╝╚═════╝ ╚══════╝╚═╝╚══════╝╚═╝ ╚═════╝ ╚═╝  ╚═══╝
echo.
echo  Just A Rather Very Intelligent System
echo.
echo  Checking system...
echo.

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed!
    echo Please install Python 3.8+ from https://python.org
    pause
    exit /b 1
)

:: Check if Ollama is installed
ollama --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARNING] Ollama not detected!
    echo.
    echo This setup will:
    echo   1. Download and install Ollama (~200MB)
    echo   2. Download AI model (~2GB)
    echo   3. Install Python dependencies
    echo.
    set /p INSTALL="Continue with setup? (Y/n): "
    if /i not "%INSTALL%"=="y" (
        echo Setup cancelled.
        pause
        exit /b
    )
    echo.
    echo Starting bootstrapper...
    python "%~dp0bootstrap.py"
    exit /b
)

:: Check if Ollama is running
curl -s http://localhost:11434/api/tags >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Starting Ollama service...
    start /min cmd /c "ollama serve"
    timeout /t 3 /nobreak >nul
)

:: Check if model is downloaded
ollama list | findstr "llama3.2" >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Downloading AI model (llama3.2)...
    echo This may take a few minutes...
    ollama pull llama3.2
)

:: Check Python dependencies
echo [INFO] Checking dependencies...
pip show speechrecognition >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Installing Python dependencies...
    pip install speechrecognition pyttsx3 requests psutil Pillow >nul 2>&1
)

:: Launch JARVIS
echo.
echo [READY] Starting JARVIS...
echo.
python "%~dp0main.py"

:: Keep window open if JARVIS crashes
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] JARVIS exited with error code %errorlevel%
    pause
)