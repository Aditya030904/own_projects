#!/bin/bash

# JARVIS Launcher for macOS/Linux
# Just A Rather Very Intelligent System

echo ""
echo "  ██╗    ██╗██████╗  ██████╗ ███████╗██████╗ ██╗     ██╗███████╗██╗ ██████╗ ███╗   ██╗"
echo "  ██║    ██║██╔══██╗██╔════╝ ██╔════╝██╔══██╗██║     ██║╚══███╔╝██║██╔═══██╗████╗  ██║"
echo "  ██║ █╗ ██║██████╔╝██║  ███╗█████╗  ██████╔╝██║     ██║  ███╔╝ ██║██║   ██║██╔██╗ ██║"
echo "  ██║███╗██║██╔══██╗██║   ██║██╔══╝  ██╔══██╗██║     ██║ ███╔╝  ██║██║   ██║██║╚██╗██║"
echo "  ╚███╔███╔╝██████╔╝╚██████╔╝███████╗██████╔╝███████╗██║███████╗██║╚██████╔╝██║ ╚████║"
echo "   ╚══╝╚══╝ ╚═════╝  ╚═════╝ ╚══════╝╚═════╝ ╚══════╝╚═╝╚══════╝╚═╝ ╚═════╝ ╚═╝  ╚═══╝"
echo ""
echo "  Just A Rather Very Intelligent System"
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}[ERROR] Python 3 is not installed!${NC}"
    echo "Please install Python 3.8+ from https://python.org"
    exit 1
fi

# Check Ollama
if ! command -v ollama &> /dev/null; then
    echo -e "${YELLOW}[WARNING] Ollama not detected!${NC}"
    echo ""
    echo "This setup will:"
    echo "  1. Install Ollama"
    echo "  2. Download AI model (~2GB)"
    echo "  3. Install Python dependencies"
    echo ""
    read -p "Continue with setup? (Y/n): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Setup cancelled."
        exit 1
    fi
    python3 bootstrap.py
    exit 0
fi

# Start Ollama if not running
if ! curl -s http://localhost:11434/api/tags &> /dev/null; then
    echo -e "${YELLOW}[INFO]${NC} Starting Ollama service..."
    ollama serve > /dev/null 2>&1 &
    sleep 3
fi

# Check model
if ! ollama list | grep -q "llama3.2"; then
    echo -e "${YELLOW}[INFO]${NC} Downloading AI model (llama3.2)..."
    echo "This may take a few minutes..."
    ollama pull llama3.2
fi

# Check dependencies
echo -e "${YELLOW}[INFO]${NC} Checking dependencies..."
MISSING_DEPS=""
for pkg in speechrecognition pyttsx3 requests psutil pillow; do
    if ! pip3 show "$pkg" &> /dev/null; then
        MISSING_DEPS="$MISSING_DEPS $pkg"
    fi
done

if [ -n "$MISSING_DEPS" ]; then
    echo -e "${YELLOW}[INFO]${NC} Installing dependencies..."
    pip3 install$MISSING_DEPS > /dev/null 2>&1
fi

# Launch JARVIS
echo ""
echo -e "${GREEN}[READY]${NC} Starting JARVIS..."
echo ""
python3 main.py