"""
JARVIS Bootstrapper - One-click setup and launch
Handles everything: Ollama installation, AI model download, dependencies
"""
import subprocess
import sys
import os
import zipfile
import urllib.request
import shutil
from pathlib import Path

class JarvisBootstrap:
    """Handles all JARVIS setup automatically"""

    def __init__(self):
        self.jarvis_dir = Path(__file__).parent
        self.ollama_dir = Path.home() / ".jarvis" / "ollama"
        self.model_name = "llama3.2"
        self.model_dir = self.ollama_dir
        self.required_packages = [
            "speechrecognition",
            "pyttsx3",
            "requests",
            "psutil",
            "Pillow",
            "pywin32"  # For Windows
        ]

    def log(self, message, status="info"):
        """Log with styling"""
        symbols = {"info": "ℹ", "success": "✓", "error": "✗", "progress": "▸"}
        symbol = symbols.get(status, "•")
        print(f"{symbol} {message}")

    def run_command(self, cmd, description="", check=True):
        """Run a command and handle errors"""
        if description:
            self.log(description, "progress")
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=300
            )
            if result.returncode == 0:
                if description:
                    self.log(description, "success")
                return True, result.stdout
            else:
                self.log(f"Failed: {result.stderr[:200] if result.stderr else 'Unknown error'}", "error")
                return False, result.stderr
        except subprocess.TimeoutExpired:
            self.log("Command timed out", "error")
            return False, "Timeout"
        except Exception as e:
            self.log(f"Error: {str(e)}", "error")
            return False, str(e)

    def check_python(self):
        """Verify Python installation"""
        self.log("Checking Python installation...", "progress")
        version = sys.version_info
        if version.major >= 3 and version.minor >= 8:
            self.log(f"Python {version.major}.{version.minor}.{version.micro} found", "success")
            return True
        else:
            self.log("Python 3.8+ required", "error")
            return False

    def check_ollama(self):
        """Check if Ollama is installed"""
        self.log("Checking for Ollama...", "progress")
        success, _ = self.run_command("ollama --version", check=False)
        return success

    def install_ollama_windows(self):
        """Download and install Ollama for Windows"""
        self.log("Installing Ollama for Windows...", "progress")

        ollama_exe = self.ollama_dir / "ollama.exe"
        self.ollama_dir.mkdir(parents=True, exist_ok=True)

        # Download Ollama Windows version
        url = "https://github.com/ollama/ollama/releases/download/v0.5.4/OllamaSetup.exe"
        installer_path = self.jarvis_dir / "ollama_installer.exe"

        try:
            self.log("Downloading Ollama (may take a minute)...", "progress")
            urllib.request.urlretrieve(url, installer_path)
            self.log("Ollama downloaded", "success")
        except Exception as e:
            self.log(f"Download failed: {e}", "error")
            self.log("Please install Ollama manually from https://ollama.ai", "error")
            return False

        # Run installer silently
        try:
            subprocess.run([str(installer_path), "/S"], check=True)
            self.log("Ollama installed successfully", "success")
            # Clean up installer
            installer_path.unlink(missing_ok=True)
            return True
        except:
            self.log("Installer failed, but Ollama may still be available", "warn")
            return True  # May have installed anyway

    def install_ollama(self):
        """Install Ollama based on OS"""
        if os.name == "nt":  # Windows
            return self.install_ollama_windows()
        else:
            # For Mac/Linux, direct user to ollama.ai
            self.log("Please install Ollama: https://ollama.ai", "info")
            self.log("Or run: curl -fsSL https://ollama.ai/install.sh | sh", "info")
            return False

    def start_ollama(self):
        """Start Ollama service"""
        self.log("Starting Ollama service...", "progress")

        # Check if already running
        success, _ = self.run_command(
            "powershell -Command \"Get-NetTCPConnection -LocalPort 11434 -ErrorAction SilentlyContinue\"",
            check=False
        )

        if success:
            self.log("Ollama is already running", "success")
            return True

        # Try to start it
        try:
            subprocess.Popen(
                ["ollama", "serve"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )
            import time
            time.sleep(3)
            self.log("Ollama service started", "success")
            return True
        except:
            self.log("Could not start Ollama automatically", "warn")
            return False

    def check_model(self):
        """Check if AI model is downloaded"""
        self.log("Checking for AI model...", "progress")
        success, output = self.run_command("ollama list", check=False)

        if success and self.model_name in output:
            self.log(f"Model '{self.model_name}' found", "success")
            return True
        return False

    def download_model(self):
        """Download the AI model"""
        self.log(f"Downloading AI model: {self.model_name}...", "progress")
        self.log("This will take a few minutes (about 2GB download)...", "info")

        success, output = self.run_command(
            f"ollama pull {self.model_name}",
            f"Downloading {self.model_name} model"
        )

        if success:
            self.log("AI model ready", "success")
            return True
        else:
            self.log("Model download may have failed", "warn")
            # Check if model exists anyway
            return self.check_model()

    def install_python_deps(self):
        """Install required Python packages"""
        self.log("Installing Python dependencies...", "progress")

        for package in self.required_packages:
            self.log(f"  Installing {package}...", "progress")
            success, _ = self.run_command(
                f'pip install {package}',
                f"Installing {package}",
                check=False
            )

        self.log("Dependencies installed", "success")
        return True

    def check_microphone(self):
        """Check if microphone is available"""
        try:
            import pyaudio
            p = pyaudio.PyAudio()
            for i in range(p.get_device_count()):
                if p.get_device_info_by_index(i)['maxInputChannels'] > 0:
                    p.terminate()
                    return True
            p.terminate()
        except:
            pass

        # Try speech_recognition's mic check
        try:
            import speech_recognition as sr
            r = sr.Recognizer()
            m = sr.Microphone()
            with m as source:
                r.adjust_for_ambient_noise(source, duration=0.5)
            return True
        except:
            pass

        return False

    def setup_complete(self):
        """Print setup completion summary"""
        print("\n" + "="*60)
        print("  JARVIS Setup Complete!")
        print("="*60)
        print(f"""
  Model: {self.model_name}
  Ollama: Running
  Python dependencies: Installed

  Starting JARVIS interface...
        """)

    def run(self):
        """Main bootstrap sequence"""
        print("\n" + "="*60)
        print("  JARVIS Bootstrapper - One Click Setup")
        print("="*60 + "\n")

        # Step 1: Check Python
        if not self.check_python():
            input("\nPress Enter to exit...")
            sys.exit(1)

        # Step 2: Install Ollama if needed
        if not self.check_ollama():
            print()
            install = input("Ollama not found. Install it now? (Y/n): ").strip().lower()
            if install != 'n':
                if not self.install_ollama():
                    self.log("Ollama installation requires manual intervention", "warn")
                    input("\nAfter installing Ollama, press Enter to continue...")
            else:
                self.log("Cannot proceed without Ollama", "error")
                input("\nPress Enter to exit...")
                sys.exit(1)

        # Step 3: Start Ollama
        self.start_ollama()

        # Step 4: Download model if needed
        if not self.check_model():
            print()
            download = input(f"Download AI model '{self.model_name}' now? (Y/n): ").strip().lower()
            if download != 'n':
                if not self.download_model():
                    self.log("Model download had issues", "warn")
            else:
                self.log("Model not downloaded - voice features will be limited", "warn")
        else:
            self.log("AI model ready", "success")

        # Step 5: Install Python dependencies
        print()
        deps = input("Install Python dependencies? (Y/n): ").strip().lower()
        if deps != 'n':
            self.install_python_deps()

        # Step 6: Check microphone
        print()
        if self.check_microphone():
            self.log("Microphone detected", "success")
        else:
            self.log("No microphone found - text input only", "warn")

        # Complete
        self.setup_complete()

        # Launch JARVIS
        print("Launching JARVIS...\n")
        os.chdir(self.jarvis_dir)
        subprocess.run([sys.executable, "main.py"])

if __name__ == "__main__":
    bootstrap = JarvisBootstrap()
    bootstrap.run()