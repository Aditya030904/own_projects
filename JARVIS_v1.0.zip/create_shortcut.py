"""
JARVIS Shortcut Creator - Desktop icon that opens GUI directly
"""
import os
import sys
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw

def get_desktop_path():
    """Get the user's desktop path using Windows API"""
    try:
        from win32com.client import Dispatch
        shell = Dispatch("WScript.Shell")
        desktop = Path(shell.SpecialFolders("Desktop"))
        return desktop
    except:
        for path in [
            Path.home() / "Desktop",
            Path(os.path.expandvars("%USERPROFILE%")) / "Desktop",
        ]:
            if path.exists():
                return path
        return Path.home() / "Desktop"

def create_jarvis_icon():
    """Create a JARVIS-style icon image"""
    jarvis_dir = Path(__file__).parent
    size = 256
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # JARVIS blue circle
    margin = 20
    draw.ellipse(
        [margin, margin, size - margin, size - margin],
        fill=(0, 212, 255, 255),
        outline=(0, 170, 220, 255),
        width=4
    )

    # Inner glow ring
    inner_margin = 40
    draw.ellipse(
        [inner_margin, inner_margin, size - inner_margin, size - inner_margin],
        fill=None,
        outline=(0, 255, 136, 200),
        width=2
    )

    # J letter (stylized)
    center = size // 2
    draw.line(
        [(center + 25, center - 45), (center + 25, center + 15)],
        fill=(5, 10, 30, 255),
        width=18
    )
    draw.line(
        [(center + 25, center + 15), (center - 5, center + 45)],
        fill=(5, 10, 30, 255),
        width=18
    )
    draw.line(
        [(center - 5, center + 45), (center - 25, center + 15)],
        fill=(5, 10, 30, 255),
        width=18
    )

    png_path = jarvis_dir / "jarvis_icon.png"
    img.save(png_path, format='PNG')
    return png_path

def create_shortcut():
    """Create desktop shortcut that opens GUI directly"""
    jarvis_dir = Path(__file__).parent
    run_script = jarvis_dir / "run_jarvis.py"
    icon_path = jarvis_dir / "jarvis_icon.png"
    desktop = get_desktop_path()
    shortcut_path = desktop / "JARVIS.lnk"

    try:
        from win32com.client import Dispatch
        shell = Dispatch("WScript.Shell")
        shortcut = shell.CreateShortcut(str(shortcut_path))

        # Use pythonw to hide console
        python_path = sys.executable.replace('python.exe', 'pythonw.exe')
        shortcut.TargetPath = python_path
        shortcut.Arguments = f'"{run_script}"'
        shortcut.WorkingDirectory = str(jarvis_dir)
        shortcut.Description = "JARVIS - Just A Rather Very Intelligent System"
        shortcut.IconLocation = f"{icon_path},0"
        shortcut.Save()

        print(f"Shortcut created: {shortcut_path}")
        return True
    except Exception as e:
        print(f"Failed: {e}")
        return False

def main():
    print("="*50)
    print("  JARVIS Desktop Shortcut")
    print("="*50)
    print()

    # Ensure dependencies
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        subprocess.run([sys.executable, '-m', 'pip', 'install', 'Pillow'])
        from PIL import Image, ImageDraw

    try:
        import win32com.client
    except ImportError:
        subprocess.run([sys.executable, '-m', 'pip', 'install', 'pywin32'])
        import win32com.client

    # Create icon
    print("Creating JARVIS icon...")
    create_jarvis_icon()

    # Create shortcut
    print("Creating desktop shortcut...")
    if create_shortcut():
        print("\n[DONE] JARVIS is on your Desktop!")
        print("Double-click to launch main interface.")
    else:
        print("\n[FAILED] Try running create_shortcut.py again.")

if __name__ == "__main__":
    main()