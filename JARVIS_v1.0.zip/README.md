# JARVIS - Just A Rather Very Intelligent System

A JARVIS-style AI assistant powered by local AI. No subscriptions, no cloud dependency - runs entirely on your machine.

![JARVIS](jarvis_icon.png)

## Features

- **Holographic UI** - Authentic JARVIS aesthetic with blue glow
- **Voice Interaction** - Talk to JARVIS naturally (when PyAudio available)
- **Local AI Brain** - Powered by Ollama (Llama, Mistral, etc.)
- **Conversation Memory** - JARVIS remembers your conversations
- **Web Integration** - Search, open websites, check weather
- **System Control** - Open apps, take screenshots, system info

## Requirements

- Windows 10/11 or macOS/Linux
- Python 3.8+
- NVIDIA GPU (recommended for speed, but not required)
- 8GB+ RAM

## Quick Start

### 1. Install Ollama

Download from [ollama.ai](https://ollama.ai) and install.

### 2. Download an AI Model

Open terminal and run:
```bash
ollama pull llama3.2
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run JARVIS

```bash
python main.py
```

## Usage

### Text Input
Type your message and press Enter.

### Voice Input
Click the VOICE button to start voice recognition (requires PyAudio).

### Commands
- "What's the time?" - Current time
- "What's the weather?" - Weather info
- "Search for [topic]" - Web search
- "Take a screenshot" - Capture screen
- "System info" - Hardware details

## Troubleshooting

### "Cannot connect to Ollama"
1. Make sure Ollama is running: `ollama serve`
2. Check the model is downloaded: `ollama list`

### Voice input not working
- Install PyAudio: `pip install PyAudio`
- Or use text-only mode (auto-enabled if PyAudio unavailable)

## Customization

Edit the source files to customize:
- `brain.py` - Change AI model or personality
- `ui.py` - Modify interface colors and layout
- `voice.py` - Adjust voice settings

## Privacy

All AI processing happens locally via Ollama. No data is sent to external servers.

## License

This project is for educational purposes. JARVIS is a trademark of Marvel Studios.

---

*"Sir, I am at your service."* - JARVIS