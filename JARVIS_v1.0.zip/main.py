"""
JARVIS - Just A Rather Very Intelligent System
A JARVIS-style AI assistant powered by local AI
"""
import sys
import os
from datetime import datetime
from ui import JarvisUI
from voice import VoiceManager
from brain import JarvisBrain
from memory import ConversationMemory
from capabilities import Capabilities

class Jarvis:
    """Main JARVIS assistant class"""

    def __init__(self):
        self.ui = JarvisUI()
        self.voice = VoiceManager()
        self.brain = JarvisBrain()
        self.memory = ConversationMemory()
        self.capabilities = Capabilities()
        self.is_listening = False
        self.is_speaking = False

    def boot(self):
        """Initialize JARVIS and greet the user"""
        self.ui.show_boot_sequence()
        self.ui.add_message("JARVIS", "Initializing systems...", "jarvis")
        self.ui.root.update()

        # Initialize voice
        self.voice.init()

        # Check Ollama connection
        if self.brain.check_connection():
            self.ui.add_message("JARVIS", "Neural network online. All systems nominal, sir.", "jarvis")
        else:
            self.ui.add_message("JARVIS", "Warning: Cannot connect to AI core. Please ensure Ollama is running.", "jarvis")

        # Load conversation history
        self.memory.load()
        self.ui.add_message("JARVIS", "Memory banks loaded. At your service.", "jarvis")

        # Initial greeting with voice
        greeting = "Hello, sir. I am JARVIS. How may I assist you today?"
        self.ui.add_message("JARVIS", greeting, "jarvis")
        self.speak(greeting)

    def speak(self, text):
        """Convert text to speech"""
        if not self.is_speaking:
            self.is_speaking = True
            self.voice.speak(text)
            self.is_speaking = False

    def process_command(self, command):
        """Process user command and generate response"""
        if not command.strip():
            return

        # Display user message
        self.ui.add_message("You", command, "user")

        # Add to memory
        self.memory.add("user", command)

        # Show "thinking" animation
        self.ui.show_thinking()

        # Generate response
        response = self.brain.think(command, self.memory.get_history())

        # Add to memory
        self.memory.add("jarvis", response)

        # Display and speak response
        self.ui.hide_thinking()
        self.ui.add_message("JARVIS", response, "jarvis")

        if self.ui.speak_enabled:
            self.speak(response)

        # Save memory
        self.memory.save()

    def run(self):
        """Main loop"""
        self.ui.root.mainloop()

def main():
    """Entry point"""
    jarvis = Jarvis()
    jarvis.boot()
    jarvis.run()

if __name__ == "__main__":
    main()