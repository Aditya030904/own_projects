"""
JARVIS Auto-Installer - Installs Ollama + Dependencies + Model
Run this ONCE to set everything up, then use LAUNCH.bat to start.
"""
import subprocess
import sys
import os
import urllib.request
import zipfile
import shutil
from pathlib import Path

def is_admin():
    """Check if running as administrator (Windows)"""
    try:
        import ctypes
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except:
        return False

def run_powershell(command):
    """Run PowerShell command"""
    result = subprocess.run(
        ['powershell', '-Command', command],
        capture_output=True,
        text=True
    )
    return result.returncode == 0, result.stdout, result.stderr

def install_ollama():
    """Download and install Ollama silently"""
    print("  Downloading Ollama...")

    url = "https://github.com/ollama/ollama/releases/download/v0.5.4/OllamaSetup.exe"
    exe_path = Path("ollama_installer.exe")

    try:
        urllib.request.urlretrieve(url, exe_path)
        print("  Running installer...")

        # Run silently
        subprocess.run([str(exe_path), '/S'], check=True)

        # Clean up
        exe_path.unlink(missing_ok=True)

        print("  Ollama installed successfully!")
        return True
    except Exception as e:
        print(f"  Error: {e}")
        return False

def install_python_deps():
    """Install required Python packages"""
    packages = [
        'speechrecognition',
        'pyttsx3',
        'requests',
        'psutil',
        'Pillow'
    ]

    print("\n  Installing Python dependencies...")
    for pkg in packages:
        try:
            subprocess.run([sys.executable, '-m', 'pip', 'install', pkg],
                         capture_output=True, timeout=60)
            print(f"    ✓ {pkg}")
        except:
            print(f"    ✗ {pkg}")

def download_model():
    """Download Ollama model"""
    print("\n  Downloading AI model (llama3.2)...")
    print("  This may take 5-10 minutes depending on your internet...")

    try:
        result = subprocess.run(
            ['ollama', 'pull', 'llama3.2'],
            capture_output=True,
            text=True,
            timeout=1800  # 30 min timeout
        )

        if result.returncode == 0:
            print("  Model downloaded successfully!")
            return True
        else:
            print(f"  Warning: {result.stderr[:200]}")
            return False
    except subprocess.TimeoutExpired:
        print("  Model download timed out. Try again later with: ollama pull llama3.2")
        return False
    except Exception as e:
        print(f"  Error: {e}")
        return False

def main():
    print("="*60)
    print("  JARVIS Auto-Installer")
    print("  One-click setup for everything")
    print("="*60)

    # Step 1: Install Ollama
    print("\n[1/3] Installing Ollama (AI runtime)...")
    success, out, err = run_powershell("Get-Command ollama -ErrorAction SilentlyContinue")
    if not success or not out.strip():
        install_ollama()
    else:
        print("  Ollama already installed!")

    # Step 2: Install Python dependencies
    print("\n[2/3] Installing Python packages...")
    install_python_deps()

    # Step 3: Download AI model
    print("\n[3/3] Downloading AI brain...")
    download_model()

    # Done
    print("\n" + "="*60)
    print("  INSTALLATION COMPLETE!")
    print("="*60)
    print("""
  Next step: Run LAUNCH.bat to start JARVIS

  If JARVIS doesn't start:
  1. Make sure Ollama is running: ollama serve
  2. Then run: python main.py
    """)

    input("\nPress Enter to exit...")

if __name__ == "__main__":
    if os.name == "nt":
        # Request admin if needed (for Ollama install)
        if not is_admin():
            print("Requesting administrator privileges...")
            import ctypes
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, __file__, None, 1)
            sys.exit()

    main()