# JARVIS Privacy & Security

## Your Data Stays With You 🔒

JARVIS is built with privacy as a core principle. Here's exactly what happens to your data:

---

## What Stays LOCAL

### ✅ AI Processing
- All AI inference runs via Ollama on YOUR machine
- The AI model runs entirely locally
- **Zero data sent to OpenAI, Google, or any external AI provider**

### ✅ Voice Processing (Default Mode)
- Text-to-Speech uses your system's built-in TTS engine
- No voice data is transmitted anywhere
- Speech-to-Text can use offline Whisper (optional, more setup)

### ✅ Conversation History
- Stored only in `memory.json` on YOUR local disk
- Never uploaded to any server
- You can delete it anytime (just delete `memory.json`)

### ✅ All Core Features
- Web search opens YOUR browser (you control it)
- Screenshots saved locally
- File operations only touch YOUR filesystem

---

## What Goes Online (OPTIONAL)

### ⚠️ Web Features (Can Be Disabled)
If you enable `ENABLE_WEB_FEATURES = True` in `capabilities.py`:
- **Weather**: Queries `wttr.in` public API (city name only)
- **Web Search**: Opens your default browser to Google

These are standard web requests — no account, no login, no tracking.

### ⚠️ Speech-to-Text (Default)
Default uses Google's free speech API for transcription. This is:
- Request-based (no voice storage by Google)
- Industry standard (like Siri, Google Assistant)
- **Can be disabled**: Set `USE_OFFLINE_STT = True` in `voice.py` and install Whisper

---

## How to Go FULL OFFLINE

1. **Disable web features:**
   ```python
   # In capabilities.py
   ENABLE_WEB_FEATURES = False
   ```

2. **Use offline speech recognition:**
   ```python
   # In voice.py
   USE_OFFLINE_STT = True
   ```
   Then run: `pip install openai-whisper` and `ollama pull whisper`

3. **Use only Ollama:**
   - Ollama runs entirely locally
   - No internet required after downloading the model
   - Air-gapped mode: physically disconnect from internet

---

## What JARVIS NEVER Does

- ❌ Sends your conversations to any server
- ❌ Logs keystrokes or monitors your activity
- ❌ Collects personal information
- ❌ Connects to telemetry or analytics
- ❌ Sells or shares any data
- ❌ Runs background processes when not active

---

## Network Connections

When fully operational, JARVIS may connect to:
1. `localhost:11434` — Ollama (local AI) — YOUR machine only
2. `wttr.in` — Weather API (if enabled) — public, anonymous
3. `google.com` — Only when YOU ask for a web search

**That's it.** No hidden connections.

---

## If You See Something Strange

If JARVIS tries to connect somewhere unexpected, it's likely:
- A bug in pyttsx3 checking for updates
- Python checking package metadata

You can verify connections with:
```bash
# Windows
netstat -an | findstr "ESTABLISHED"

# Or use Wireshark/Fiddler for detailed analysis
```

---

## Your Control

- Delete `memory.json` anytime to wipe conversation history
- Edit any `.py` file to customize behavior
- Monitor network connections via your router or system tools
- Air-gap: JARVIS works fully offline once Ollama is set up

---

*"Sir, I am programmed to protect your privacy. That is not a feature — it is a core directive."* — JARVIS