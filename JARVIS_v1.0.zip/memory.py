"""
JARVIS Memory Module - Conversation History
"""
import json
import os
from datetime import datetime

class ConversationMemory:
    """Manages JARVIS conversation history and context"""

    def __init__(self, memory_file="memory.json"):
        self.memory_file = memory_file
        self.history = []
        self.max_history = 100  # Keep last 100 exchanges

    def load(self):
        """Load conversation history from file"""
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, 'r') as f:
                    data = json.load(f)
                    self.history = data.get('history', [])
                print(f"Loaded {len(self.history)} previous exchanges.")
            except Exception as e:
                print(f"Could not load memory: {e}")
                self.history = []
        else:
            print("No previous memory found. Starting fresh.")
            self.history = []

    def save(self):
        """Save conversation history to file"""
        try:
            with open(self.memory_file, 'w') as f:
                json.dump({
                    'history': self.history[-self.max_history:],
                    'last_updated': datetime.now().isoformat()
                }, f, indent=2)
        except Exception as e:
            print(f"Could not save memory: {e}")

    def add(self, role, content):
        """Add a conversation entry"""
        self.history.append({
            'role': role,  # 'user' or 'jarvis'
            'content': content,
            'timestamp': datetime.now().isoformat()
        })

        # Keep history bounded
        if len(self.history) > self.max_history * 2:
            self.history = self.history[-self.max_history:]

    def get_history(self):
        """Get conversation history for AI context"""
        return [(entry['role'], entry['content']) for entry in self.history]

    def clear(self):
        """Clear all conversation history"""
        self.history = []
        if os.path.exists(self.memory_file):
            os.remove(self.memory_file)
        print("Memory cleared.")

    def search(self, query):
        """Search through conversation history"""
        results = []
        query_lower = query.lower()
        for entry in self.history:
            if query_lower in entry['content'].lower():
                results.append(entry)
        return results

    def get_stats(self):
        """Get memory statistics"""
        return {
            'total_exchanges': len(self.history),
            'oldest': self.history[0]['timestamp'] if self.history else None,
            'newest': self.history[-1]['timestamp'] if self.history else None,
            'file_size': os.path.getsize(self.memory_file) if os.path.exists(self.memory_file) else 0
        }