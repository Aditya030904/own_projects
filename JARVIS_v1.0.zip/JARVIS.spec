# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

# JARVIS PyInstaller Specification
# Build command: pyinstaller JARVIS.spec

a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[
        # Include all JARVIS Python modules
        ('ui.py', '.'),
        ('voice.py', '.'),
        ('brain.py', '.'),
        ('memory.py', '.'),
        ('capabilities.py', '.'),
        ('main.py', '.'),
    ],
    hiddenimports=[
        'speech_recognition',
        'pyttsx3',
        'requests',
        'psutil',
        'PIL',
        'tkinter',
        'urllib',
        'json',
        'datetime',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['matplotlib', 'numpy', 'pandas', 'scipy'],  # Reduce size
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='JARVIS',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,  # No console window - GUI only
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,  # Add JARVIS icon here: icon='jarvis.ico'
)

# Create directory distribution (easier for updates)
dist = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='JARVIS',
)

# Alternative: Single file executable (larger but portable)
single = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='JARVIS_SingleFile',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    onefile=True,  # Single file mode
)