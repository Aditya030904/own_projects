"""
JARVIS Setup Script - Install Dependencies and Download AI Model
Run this script before starting JARVIS for the first time.
"""
import subprocess
import sys
import os

def run_command(command, description):
    """Run a command and report status"""
    print(f"\n{'='*50}")
    print(f"  {description}")
    print(f"{'='*50}")
    result = subprocess.run(command, shell=True)
    return result.returncode == 0

def check_ollama():
    """Check if Ollama is installed"""
    result = subprocess.run("ollama --version", shell=True, capture_output=True)
    return result.returncode == 0

def install_python_packages():
    """Install Python dependencies"""
    print("\nInstalling Python packages...")
    packages = [
        "speechrecognition",
        "pyttsx3",
        "requests",
        "psutil",
        "Pillow"
    ]

    for package in packages:
        print(f"Installing {package}...")
        subprocess.run(f"pip install {package}", shell=True)

def main():
    print("="*50)
    print("  JARVIS Setup Assistant")
    print("="*50)

    # Check Python version
    print(f"\nPython version: {sys.version}")

    # Check Ollama
    if check_ollama():
        print("✓ Ollama is installed")
        subprocess.run("ollama --version")
    else:
        print("✗ Ollama is NOT installed")
        print("\nPlease install Ollama from: https://ollama.ai")
        print("After installation, run this setup script again.")

    # Install Python packages
    print("\nInstalling Python dependencies...")
    install_python_packages()

    # Download AI model
    print("\n" + "="*50)
    print("  Downloading AI Model")
    print("="*50)
    print("\nWe recommend 'llama3.2' for general use.")
    print("For better performance with NVIDIA GPU, use 'llama3.2:3b'")
    print("\nTo download, run in terminal:")
    print("  ollama pull llama3.2")
    print("\nOr pull a different model:")
    print("  ollama pull mistral")
    print("  ollama pull phi3")
    print("  ollama pull mixtral")

    print("\n" + "="*50)
    print("  Setup Complete!")
    print("="*50)
    print("\nNext steps:")
    print("1. Start Ollama: ollama serve")
    print("2. Run JARVIS: python main.py")
    print("\nFor voice input, ensure a microphone is connected.")

if __name__ == "__main__":
    main()