"""
JARVIS UI Module - Holographic Interface
"""
import tkinter as tk
from tkinter import scrolledtext, ttk
import threading
import time
import random
import sys

class JarvisUI:
    """JARVIS holographic user interface"""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("JARVIS - Just A Rather Very Intelligent System")
        self.root.geometry("1000x700")
        self.root.configure(bg='#0a0a1a')

        # Force window to appear
        self.root.update()

        # State
        self.speak_enabled = True
        self.thinking_active = False

        self.setup_ui()

        # Force window to front and focus
        self.root.lift()
        self.root.focus_force()

    def setup_ui(self):
        """Setup the holographic interface"""

        # Title bar with JARVIS branding
        title_frame = tk.Frame(self.root, bg='#0a0a1a', height=60)
        title_frame.pack(fill='x', padx=20, pady=(20, 10))
        title_frame.pack_propagate(False)

        title_label = tk.Label(
            title_frame,
            text="JARVIS",
            font=('Courier New', 28, 'bold'),
            fg='#00d4ff',
            bg='#0a0a1a'
        )
        title_label.pack(side='left')

        status_label = tk.Label(
            title_frame,
            text="ONLINE",
            font=('Courier New', 12),
            fg='#00ff88',
            bg='#0a0a1a'
        )
        status_label.pack(side='right', pady=10)

        # Main chat area with holographic border
        chat_frame = tk.Frame(self.root, bg='#0a0a1a', padx=20, pady=10)
        chat_frame.pack(fill='both', expand=True, padx=20, pady=10)

        # Holographic border effect
        border_frame = tk.Frame(chat_frame, bg='#00d4ff', bd=0)
        border_frame.pack(fill='both', expand=True)

        # Inner dark area
        inner_frame = tk.Frame(border_frame, bg='#050510')
        inner_frame.pack(fill='both', expand=True, padx=3, pady=3)

        # Chat display
        self.chat_display = scrolledtext.ScrolledText(
            inner_frame,
            wrap=tk.WORD,
            font=('Courier New', 12),
            fg='#00d4ff',
            bg='#050510',
            insertbackground='#00d4ff',
            relief='flat',
            state='disabled'
        )
        self.chat_display.pack(fill='both', expand=True, padx=15, pady=15)

        # Configure text tags
        self.chat_display.tag_configure('user', foreground='#00ff88')
        self.chat_display.tag_configure('jarvis', foreground='#00d4ff')
        self.chat_display.tag_configure('system', foreground='#888888')
        self.chat_display.tag_configure('thinking', foreground='#ffaa00')

        # Input area
        input_frame = tk.Frame(self.root, bg='#0a0a1a', padx=20, pady=15)

        # Entry field
        self.input_entry = tk.Entry(
            input_frame,
            font=('Courier New', 14),
            fg='#00d4ff',
            bg='#0a1525',
            insertbackground='#00d4ff',
            relief='flat'
        )
        self.input_entry.pack(side='left', fill='x', expand=True, ipady=10, padx=(0, 10))
        self.input_entry.bind('<Return>', self.on_submit)

        # Voice button
        self.voice_btn = tk.Button(
            input_frame,
            text="VOICE",
            font=('Courier New', 10),
            fg='#00d4ff',
            bg='#0a1525',
            activeforeground='#00ff88',
            relief='flat',
            command=self.toggle_voice
        )
        self.voice_btn.pack(side='right', ipadx=15, ipady=5)

        # Speak toggle
        self.speak_btn = tk.Button(
            input_frame,
            text="SPEAK",
            font=('Courier New', 10),
            fg='#00d4ff',
            bg='#0a1525',
            activeforeground='#00ff88',
            relief='flat',
            command=self.toggle_speak
        )
        self.speak_btn.pack(side='right', ipadx=15, ipady=5, padx=(0, 10))

        input_frame.pack(fill='x')

        # Start voice listening indicator
        self.voice_indicator = tk.Label(
            self.root,
            text="",
            font=('Courier New', 10),
            fg='#ff4444',
            bg='#0a0a1a'
        )
        self.voice_indicator.pack()

        # Bind window close
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def add_message(self, sender, message, msg_type='system'):
        """Add a message to the chat display"""
        self.chat_display.config(state='normal')

        timestamp = time.strftime('%H:%M')

        if sender == "You":
            self.chat_display.insert('end', f'\n[{timestamp}] ', 'system')
            self.chat_display.insert('end', f'{sender}: ', 'user')
        else:
            self.chat_display.insert('end', f'\n[{timestamp}] ', 'system')
            self.chat_display.insert('end', f'{sender}: ', 'jarvis')

        self.chat_display.insert('end', f'{message}\n', msg_type)

        self.chat_display.see('end')
        self.chat_display.config(state='disabled')

    def show_thinking(self):
        """Show thinking animation"""
        self.thinking_active = True
        self.add_message("JARVIS", "Processing...", "thinking")

    def hide_thinking(self):
        """Hide thinking message"""
        self.thinking_active = False

    def on_submit(self, event=None):
        """Handle text input submission"""
        command = self.input_entry.get().strip()
        if command:
            self.input_entry.delete(0, 'end')
            return command
        return None

    def toggle_voice(self):
        """Toggle voice input"""
        pass

    def toggle_speak(self):
        """Toggle speech output"""
        self.speak_enabled = not self.speak_enabled
        if self.speak_enabled:
            self.speak_btn.config(text="SPEAK")
        else:
            self.speak_btn.config(text="MUTED")

    def show_boot_sequence(self):
        """Show JARVIS boot animation (minimal for GUI)"""
        pass  # GUI doesn't need console boot sequence

    def on_close(self):
        """Handle window close"""
        self.root.destroy()
        sys.exit()