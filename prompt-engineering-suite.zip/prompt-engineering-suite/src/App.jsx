import { useState } from "react";
import OptimizerPanel from "./components/OptimizerPanel";
import FirewallPanel from "./components/FirewallPanel";
import "./App.css";

export default function App() {
  const [activeTab, setActiveTab] = useState("optimizer");

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-inner">
          <div className="logo">
            <span className="logo-icon">⚙</span>
            <span className="logo-text">prompt<strong>suite</strong></span>
          </div>
          <p className="header-sub">Meta-Prompt Optimizer · Security Firewall</p>
        </div>
      </header>

      <main className="app-main">
        <div className="tabs">
          <button
            className={`tab ${activeTab === "optimizer" ? "active" : ""}`}
            onClick={() => setActiveTab("optimizer")}
          >
            🪄 Prompt Optimizer
          </button>
          <button
            className={`tab ${activeTab === "firewall" ? "active" : ""}`}
            onClick={() => setActiveTab("firewall")}
          >
            🛡 Security Firewall
          </button>
        </div>

        <div className="panel-container">
          {activeTab === "optimizer" ? <OptimizerPanel /> : <FirewallPanel />}
        </div>
      </main>
    </div>
  );
}
