import { useState } from "react";
import TagSelector from "./TagSelector";
import { callClaude } from "../api/claude";

const TECHNIQUES = [
  { value: "chain-of-thought", label: "chain-of-thought" },
  { value: "role-definition", label: "role definition" },
  { value: "few-shot", label: "few-shot examples" },
  { value: "output-format", label: "output format" },
  { value: "tone-control", label: "tone control" },
  { value: "constraints", label: "constraints" },
  { value: "tree-of-thought", label: "tree-of-thought" },
];

const METRICS = [
  { value: "clarity", label: "clarity" },
  { value: "specificity", label: "specificity" },
  { value: "creativity", label: "creativity" },
  { value: "tone", label: "tone match" },
  { value: "length", label: "length" },
  { value: "toxicity", label: "toxicity check" },
];

export default function OptimizerPanel() {
  const [basePrompt, setBasePrompt] = useState("");
  const [techniques, setTechniques] = useState(["chain-of-thought", "role-definition"]);
  const [metrics, setMetrics] = useState(["clarity", "specificity"]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);

  function toggleTag(arr, setArr, val) {
    setArr((prev) => prev.includes(val) ? prev.filter((v) => v !== val) : [...prev, val]);
  }

  async function handleOptimize() {
    if (!basePrompt.trim()) return;
    setLoading(true);
    setError("");
    setResult(null);

    const system = `You are an expert prompt engineer. Given a basic prompt, do three things:

1. OPTIMIZE: Expand it into a highly structured, expert-quality prompt using these techniques: ${techniques.join(", ")}. Apply role definitions, chain-of-thought reasoning, few-shot examples, and output formatting where relevant.

2. EVALUATE: Score the ORIGINAL prompt on these metrics: ${metrics.join(", ")}. Give each a score from 1 to 10.

3. SAMPLE: Write a short sample output (3-5 sentences) that the OPTIMIZED prompt would produce.

Respond ONLY with valid JSON, no markdown fences:
{
  "optimized_prompt": "...",
  "metrics": { "metric_name": score_number },
  "sample_output": "..."
}`;

    try {
      const data = await callClaude({
        system,
        userMessage: `Base prompt: "${basePrompt}"`,
      });
      setResult(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  function copyText(text) {
    navigator.clipboard.writeText(text).catch(() => {});
  }

  return (
    <div>
      <div className="field-group">
        <label className="field-label">Base prompt</label>
        <textarea
          value={basePrompt}
          onChange={(e) => setBasePrompt(e.target.value)}
          placeholder="e.g. Write a marketing email for a SaaS product"
          rows={4}
        />
      </div>

      <div className="field-group">
        <label className="field-label">Optimization techniques</label>
        <TagSelector
          tags={TECHNIQUES}
          selected={techniques}
          onToggle={(v) => toggleTag(techniques, setTechniques, v)}
        />
      </div>

      <div className="field-group">
        <label className="field-label">Evaluation metrics</label>
        <TagSelector
          tags={METRICS}
          selected={metrics}
          onToggle={(v) => toggleTag(metrics, setMetrics, v)}
        />
      </div>

      <button className="run-btn" onClick={handleOptimize} disabled={loading || !basePrompt.trim()}>
        {loading ? <><span className="spinner" />optimizing...</> : "🪄 optimize prompt"}
      </button>

      {error && (
        <div className="result-box" style={{ marginTop: "1rem" }}>
          <div className="result-body" style={{ color: "#f87171" }}>Error: {error}</div>
        </div>
      )}

      {result && (
        <>
          <div className="divider" />

          <div className="compare-grid">
            <div className="compare-card">
              <div className="compare-head">
                <div className="compare-dot" style={{ background: "#444" }} />
                <span className="compare-label">Original</span>
              </div>
              <div className="compare-body">{basePrompt}</div>
            </div>
            <div className="compare-card">
              <div className="compare-head">
                <div className="compare-dot" style={{ background: "#7c6fff" }} />
                <span className="compare-label">Optimized</span>
              </div>
              <div className="compare-body">{result.optimized_prompt}</div>
            </div>
          </div>

          {result.metrics && (
            <div className="metrics-grid">
              {Object.entries(result.metrics).map(([key, val]) => (
                <div className="metric-card" key={key}>
                  <div className="metric-val">
                    {val}<span>/10</span>
                  </div>
                  <div className="metric-name">{key}</div>
                </div>
              ))}
            </div>
          )}

          <div className="result-box">
            <div className="result-header">
              <span className="result-title">▶ Sample output (optimized prompt)</span>
              <button className="copy-btn" onClick={() => copyText(result.sample_output)}>
                copy
              </button>
            </div>
            <div className="result-body">{result.sample_output}</div>
          </div>

          <div className="result-box">
            <div className="result-header">
              <span className="result-title">✦ Full optimized prompt</span>
              <button className="copy-btn" onClick={() => copyText(result.optimized_prompt)}>
                copy
              </button>
            </div>
            <div className="result-body">{result.optimized_prompt}</div>
          </div>
        </>
      )}
    </div>
  );
}
