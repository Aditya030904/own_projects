export default function TagSelector({ tags, selected, onToggle }) {
  return (
    <div className="tag-row">
      {tags.map((tag) => (
        <button
          key={tag.value}
          className={`tag ${selected.includes(tag.value) ? "selected" : ""}`}
          onClick={() => onToggle(tag.value)}
        >
          {tag.label}
        </button>
      ))}
    </div>
  );
}
