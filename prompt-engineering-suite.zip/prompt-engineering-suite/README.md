# ⚙ Prompt Engineering Suite

A production-ready React app with two AI-powered tools built on the Anthropic Claude API:

- **🪄 Meta-Prompt Optimizer** — Transforms basic prompts into structured, expert-quality prompts using Chain-of-Thought, Few-Shot, Tree-of-Thought, and more. Evaluates output quality with custom metrics.
- **🛡 Security Firewall** — Scans incoming user prompts for jailbreaks, prompt injections, DAN attacks, system prompt leaks, and other LLM security threats.

![Demo](https://img.shields.io/badge/React-18-61DAFB?logo=react) ![Vite](https://img.shields.io/badge/Vite-5-646CFF?logo=vite) ![Claude](https://img.shields.io/badge/Claude-Sonnet-CC785C)

---

## 🚀 Quick Start

### 1. Clone the repo

```bash
git clone https://github.com/YOUR_USERNAME/prompt-engineering-suite.git
cd prompt-engineering-suite
```

### 2. Install dependencies

```bash
npm install
```

### 3. Set up your API key

```bash
cp .env.example .env
```

Edit `.env` and add your Anthropic API key:

```
VITE_ANTHROPIC_API_KEY=sk-ant-...
```

Get a key at [console.anthropic.com](https://console.anthropic.com).

### 4. Run the dev server

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173).

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + Vite |
| Styling | Plain CSS with CSS variables |
| AI | Anthropic Claude (`claude-sonnet-4-20250514`) |
| Font | JetBrains Mono (monospace theme) |

---

## 📁 Project Structure

```
prompt-engineering-suite/
├── src/
│   ├── api/
│   │   └── claude.js          # Anthropic API wrapper
│   ├── components/
│   │   ├── OptimizerPanel.jsx # Prompt optimizer UI + logic
│   │   ├── FirewallPanel.jsx  # Security scanner UI + logic
│   │   └── TagSelector.jsx    # Reusable tag toggle component
│   ├── App.jsx                # Root component + tab navigation
│   ├── App.css                # All styles
│   └── main.jsx               # React entry point
├── index.html
├── vite.config.js
├── .env.example
└── package.json
```

---

## ✨ Features

### Prompt Optimizer

- Select optimization techniques: Chain-of-Thought, Role Definition, Few-Shot Examples, Output Format, Tone Control, Constraints, Tree-of-Thought
- Select evaluation metrics: Clarity, Specificity, Creativity, Tone Match, Length, Toxicity Check
- Side-by-side before/after comparison
- Per-metric scores (1–10)
- Sample output from the optimized prompt
- One-click copy for optimized prompt

### Security Firewall

- Detects: Jailbreak attempts, Prompt injection, System prompt leaks, DAN/persona overrides, PII extraction, Hallucination triggers, Context escape
- Returns a SAFE / SUSPICIOUS / DANGEROUS verdict
- 0–100 risk score
- Per-threat detection with explanations
- Actionable recommendations

---

## 🔐 Security Note

This app calls the Anthropic API directly from the browser using `VITE_ANTHROPIC_API_KEY`. This is fine for local development and demos. For a production deployment, move the API calls to a backend server (Node/Express, FastAPI, etc.) so the key is never exposed to clients.

---

## 🏗 Build for Production

```bash
npm run build
```

Output is in `dist/`. Deploy to Vercel, Netlify, or any static host.

---

## 📄 License

MIT
